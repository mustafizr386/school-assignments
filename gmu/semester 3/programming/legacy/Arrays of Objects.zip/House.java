import javax.swing.JOptionPane;

public class House {
   public static void main(String[] args) {
      Rectangle[] rooms = new Rectangle[5];
      rooms[0] = new Rectangle();
      rooms[0].setName("Kitchen");
   }
}
