import javax.swing.JOptionPane;

public class ItemsWithParallelArrays {
   public static void main(String[] args) {
      String[] descriptions = {"Vitamins", "Tomatoes", "Lettuce", "Cucumbers"};
      double[] prices = {7.99, 1.49, 2.99, 0.99};
   }
}