import javax.swing.JOptionPane;

public class HousePopulated {
   public static void main(String[] args) {
      Rectangle[] rooms = new Rectangle[] {
         new Rectangle("Kitchen"),
         new Rectangle("Bedroom"),
         new Rectangle("Dining Room"),
         new Rectangle("Living Room"),
         new Rectangle("Garage")
      };
   }
}