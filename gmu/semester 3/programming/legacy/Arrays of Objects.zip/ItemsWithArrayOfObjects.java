import javax.swing.JOptionPane;

public class ItemsWithArrayOfObjects {
   public static void main(String[] args) {
      Item[] shoppingBasket = new Item[] {
         new Item("Vitamins", 7.99),
         new Item("Tomatoes", 1.49),
         new Item("Lettuce", 2.99),
         new Item("Cucumbers", 0.99)
      };
   }
}