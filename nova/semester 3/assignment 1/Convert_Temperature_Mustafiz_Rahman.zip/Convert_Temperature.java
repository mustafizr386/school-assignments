//Mustafiz Rahman
//5/25/2020
//ITP 120 040A
//Professor Gonchar

import java.util.*;

public class Convert_Temperature
{

   public static void main(String[]args)
   {
      Scanner input = new Scanner(System.in);
      System.out.println("input temperature in Fahrenheit:");    
      System.out.printf("%.2f",(input.nextFloat()-32) * 5/9);
   }
}